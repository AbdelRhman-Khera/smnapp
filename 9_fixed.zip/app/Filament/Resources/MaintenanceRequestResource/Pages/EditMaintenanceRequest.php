<?php

namespace App\Filament\Resources\MaintenanceRequestResource\Pages;

use App\Filament\Resources\MaintenanceRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditMaintenanceRequest extends EditRecord
{
    protected static string $resource = MaintenanceRequestResource::class;

    /**
     * @var array<int, array{product_id:int|string|null, quantity:int|string|null}>
     */
    protected array $productsToSync = [];

    protected function mutateFormDataBeforeSave(array $data): array
    {
        // Products are stored on the pivot table (maintenance_request_product)
        $this->productsToSync = $data['products'] ?? [];
        unset($data['products']);

        return $data;
    }

    protected function afterSave(): void
    {
        $maintenanceRequest = $this->getRecord();

        // Sync products with quantity on pivot
        $sync = [];
        foreach ($this->productsToSync as $item) {
            $productId = (int) ($item['product_id'] ?? 0);
            $quantity = (int) ($item['quantity'] ?? 1);

            if ($productId > 0) {
                $sync[$productId] = ['quantity' => max(1, $quantity)];
            }
        }

        if (!empty($sync)) {
            $maintenanceRequest->products()->sync($sync);
        } else {
            // If user removed all products, detach.
            $maintenanceRequest->products()->detach();
        }
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\ViewAction::make(),
            Actions\DeleteAction::make(),
        ];
    }
}
