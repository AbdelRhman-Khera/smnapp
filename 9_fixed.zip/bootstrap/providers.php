<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    Paytabscom\Laravel_paytabs\PaypageServiceProvider::class,
];
