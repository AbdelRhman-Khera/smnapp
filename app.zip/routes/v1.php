<?php

use App\Http\Controllers\AddressController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\MaintenanceRequestController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SapController;
use App\Http\Controllers\TechnicianController;
use App\Http\Controllers\TechnicianSparePartRequestController;
use App\Http\Middleware\SapBasicAuth;
use App\Http\Middleware\SetLanguage;


// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

Route::middleware([SetLanguage::class])->group(function () {
    Route::post('/customer/register', [CustomerController::class, 'register']);
    Route::post('/customer/verify-otp', [CustomerController::class, 'verifyOtp']);
    Route::post('/customer/login', [CustomerController::class, 'login'])->name('login');
    Route::post('/customer/forgot-password', [CustomerController::class, 'forgotPassword']);
    Route::post('/customer/reset-password', [CustomerController::class, 'resetPassword']);
    Route::post('/technician/login', [TechnicianController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/customer/logout', [CustomerController::class, 'logout']);
        Route::put('/customer/update-profile', [CustomerController::class, 'updateProfile']);
        Route::put('/customer/update-phone', [CustomerController::class, 'updatePhoneNumber']);
        Route::post('/customer/change-password', [CustomerController::class, 'changePassword']);
        Route::get('/customer', [CustomerController::class, 'getCustomer']);
        Route::delete('/customer/remove', [CustomerController::class, 'removeCustomer']);
        Route::post('/customer/update-fcm-token', [CustomerController::class, 'updateFcmToken']);

        //// address
        Route::get('/addresses', [AddressController::class, 'index']);
        Route::get('/addresses/{address}', [AddressController::class, 'show']);
        Route::post('/addresses', [AddressController::class, 'store']);
        Route::put('/addresses/{address}', [AddressController::class, 'update']);
        Route::delete('/addresses/{address}', [AddressController::class, 'destroy']);

        //// products
        Route::post('/customer/products', [ProductController::class, 'addProductToCustomer']);
        Route::get('/customer/products', [ProductController::class, 'getCustomerProducts']);
        Route::delete('/customer/products/{productId}', [ProductController::class, 'removeProductFromCustomer']);

        ////// technicians
        Route::post('/technician/change-password', [TechnicianController::class, 'changePassword']);
        Route::get('/technician', [TechnicianController::class, 'getTechnician']);
        Route::post('/technician/logout', [TechnicianController::class, 'logout']);
        Route::get('/technician/requests-summary', [TechnicianController::class, 'getRequestsSummary']);
        Route::get('/technician/requests', [TechnicianController::class, 'getAllRequests']);
        Route::post('/technician/update-fcm-token', [TechnicianController::class, 'updateFcmToken']);
        // Route::delete('/technician/remove', [TechnicianController::class, 'removeTechnician']);

        Route::get('/technician/freelancer-open-requests', [TechnicianController::class, 'getFreelancerOpenRequests']);

        Route::post('/technician/freelancer-requests/{id}/claim', [TechnicianController::class, 'claimFreelancerRequest']);


        Route::get('/sap-order/{id}', [MaintenanceRequestController::class, 'getSpecificProductByOrder']);

        // material requests
        Route::post('/technician/spare-part-request', [TechnicianSparePartRequestController::class, 'store']);
        Route::get('/technician/spare-part-requests', [TechnicianSparePartRequestController::class, 'index']);
        Route::get('/technician/spare-part-request/{id}', [TechnicianSparePartRequestController::class, 'show']);
        Route::post('/technician/spare-part-request/{id}/confirm-delivery', [TechnicianSparePartRequestController::class, 'confirmDelivery']);


        ////// maintenance request
        Route::get('/maintenance-requests/check-open-requests', [MaintenanceRequestController::class, 'checkOpenRequests']);
        Route::post('/maintenance-request', [MaintenanceRequestController::class, 'create']);
        Route::get('/maintenance-requests', [MaintenanceRequestController::class, 'index']);
        Route::get('/maintenance-request/{id}', [MaintenanceRequestController::class, 'show']);
        Route::post('/maintenance-request/{id}/cancel', [MaintenanceRequestController::class, 'cancel']);
        // Route::post('/maintenance-request/{maintenanceRequest}/rate', [MaintenanceRequestController::class, 'rate']);
        // Route::post('/maintenance-request/{maintenanceRequest}/status', [MaintenanceRequestController::class, 'updateStatus']);
        Route::post('/get-available-slots', [MaintenanceRequestController::class, 'getAvailableSlots']);
        Route::post('/maintenance-requests/nearest-slot', [MaintenanceRequestController::class, 'getNearestAvailableSlot']);
        Route::post('/maintenance-request/assign', [MaintenanceRequestController::class, 'assignSlot']);

        Route::post('/maintenance-request/{id}/open-for-freelancers', [MaintenanceRequestController::class, 'openForFreelancers']);

        Route::post('/maintenance-request/{id}/set-on-the-way', [TechnicianController::class, 'setOnTheWay']);
        Route::post('/maintenance-request/{id}/set-in-progress', [TechnicianController::class, 'setInProgress']);
        Route::post('/maintenance-request/{id}/set-waiting-for-payment', [TechnicianController::class, 'setWaitingForPayment']);
        Route::post('/maintenance-request/{id}/confirm-cash-payment', [TechnicianController::class, 'confirmCashPayment']);
        Route::post('/maintenance-request/{id}/finish-installation', [TechnicianController::class, 'finishInstallation']);

        Route::post('/maintenance-request/{id}/set-payment-method', [MaintenanceRequestController::class, 'setPaymentMethod']);
        Route::post('/maintenance-request/{id}/submit-feedback', [MaintenanceRequestController::class, 'submitFeedback']);



        Route::post('/support-form', [LandingController::class, 'storeSupportForm']);

        /////notifications

        Route::get('/notifications', [NotificationController::class, 'getNotifications']);
        Route::get('/notifications/unread', [NotificationController::class, 'getUnreadNotifications']);
        Route::post('/notifications/{id}/read', [NotificationController::class, 'markNotificationAsRead']);
        Route::post('/notifications/read-all', [NotificationController::class, 'markAllNotificationsAsRead']);
    });
    /////paytabs
    Route::post('/payment/callback/{id}', [MaintenanceRequestController::class, 'paymentCallback'])->name('payment.callback');
    Route::post('/payment/success/{id}', [MaintenanceRequestController::class, 'paymentCallback'])->name('payment.success');
    Route::post('/payment/mobileCallback', [MaintenanceRequestController::class, 'paymentCallbackMobile'])->name('payment.mobileCallback');

    /// Master Data

    Route::get('/landing', [LandingController::class, 'getLandingPage']);
    Route::get('/sliders', [LandingController::class, 'sliders']);
    Route::get('/cities', [AddressController::class, 'cities']);
    Route::get('/cities/{city}/districts', [AddressController::class, 'getDistricts']);
    Route::get('/categories', [ProductController::class, 'getAllcategories']);
    Route::get('/products', [ProductController::class, 'getAllProducts']);
    Route::get('/pages/{slug}', [LandingController::class, 'getPage']);
    Route::get('/spare-parts', [LandingController::class, 'getSpareParts']);
    Route::get('/services', [LandingController::class, 'getServices']);
    Route::get('/branches', [TechnicianSparePartRequestController::class, 'branches']);


    Route::middleware([SapBasicAuth::class])->group(function () {
        Route::post('/sap/customer-sync', [SapController::class, 'customerSync']);
        Route::get('/sap/maintenance-request/{id}', [SapController::class, 'getMaintenanceRequestFull']);
        Route::post('/technician/spare-part-request/{id}/approve', [TechnicianSparePartRequestController::class, 'approve']);

    });
});
