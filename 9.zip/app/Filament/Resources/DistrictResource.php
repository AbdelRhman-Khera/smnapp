<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DistrictResource\Pages;
use App\Filament\Resources\DistrictResource\RelationManagers;
use App\Models\District;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\Tabs;
use Filament\Forms\Components\Tabs\Tab;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\CheckboxList;

class DistrictResource extends Resource
{
    protected static ?string $model = District::class;

    protected static ?string $navigationGroup = 'Geographical Locations';
    protected static ?string $navigationIcon = 'heroicon-o-building-library';
    protected static ?int $navigationSort = 2;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Select::make('city_id')
                ->relationship('city', 'name_ar')
                ->required(),
            Tabs::make('Language')
                ->tabs([
                    Tab::make('Arabic')->schema([
                        TextInput::make('name_ar')->required(),
                    ]),
                    Tab::make('English')->schema([
                        TextInput::make('name_en')->required(),
                    ]),
                ]),
                Forms\Components\Section::make('Availability Days')
                ->description('حدد الأيام المتاحة للتوافر في هذا الحي')
                ->schema([
                    CheckboxList::make('available_days')
                        ->options([
                            'Saturday' => 'Saturday',
                            'Sunday' => 'Sunday',
                            'Monday' => 'Monday',
                            'Tuesday' => 'Tuesday',
                            'Wednesday' => 'Wednesday',
                            'Thursday' => 'Thursday',
                            'Friday' => 'Friday',
                        ])
                        ->columns(4)
                        ->label('Available Days')
                        ->helperText('اختر الأيام اللي الفنيين متاحين فيها لهذا الحي.'),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('city.name_ar')->label('City (AR)')->sortable(),
                TextColumn::make('name_ar')->sortable()->searchable(),
                TextColumn::make('name_en')->sortable()->searchable(),

            ])->defaultSort('id', 'desc')
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDistricts::route('/'),
            'create' => Pages\CreateDistrict::route('/create'),
            'edit' => Pages\EditDistrict::route('/{record}/edit'),
        ];
    }
}
