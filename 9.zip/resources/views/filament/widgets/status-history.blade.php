<x-filament::widget>
    <x-filament::card>
        <h3 class="mb-4 text-lg font-bold">Status History</h3>
        {{ $this->table }}
    </x-filament::card>
</x-filament::widget>
